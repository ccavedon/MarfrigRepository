﻿namespace Dados
{
    public class Dados
    {

    }
}