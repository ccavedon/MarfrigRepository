﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using Entidade;
using Negocio;
using Ninject;
using Entidade.Interface;

namespace CompraDeGado
{
    public partial class Manutencao : System.Windows.Forms.Form
    {
        public string strURL = "https://localhost:44364/CompraDeGado";

        private iObter _obter;
        private iAlterar _alterar;

        public int idCompraDeGado = 0;
        public Manutencao(int idCompraDeGadoParam)
        {
            InitializeComponent();

            StandardKernel _kernel = new StandardKernel();

            _kernel.Load(Assembly.GetExecutingAssembly());

            _obter = _kernel.Get<iObter>();
            _alterar = _kernel.Get<iAlterar>();

            ObterPecuarista();
            ObterAnimal();

            idCompraDeGado = idCompraDeGadoParam;

            if (idCompraDeGado > 0)
            {
                ObterCompraDeGadoIem(idCompraDeGado);
                DesabilitarColunas();
            }
            else
            {
                AlimentarNomeColuna();
                DesabilitarColunas();
            }
        }
        private void AlimentarNomeColuna()
        {
            dgvCompraDeGadoItens.ColumnCount = 9;
            dgvCompraDeGadoItens.Columns[0].Name = "Descricao";
            dgvCompraDeGadoItens.Columns[1].Name = "Quantidade";
            dgvCompraDeGadoItens.Columns[2].Name = "Preço";
            dgvCompraDeGadoItens.Columns[3].Name = "Valor Total";
            dgvCompraDeGadoItens.Columns[4].Name = "IdCompraDeGado";
            dgvCompraDeGadoItens.Columns[5].Name = "IdPecuarista";
            dgvCompraDeGadoItens.Columns[6].Name = "IdAnimal";
            dgvCompraDeGadoItens.Columns[7].Name = "DataEntrega";
            dgvCompraDeGadoItens.Columns[8].Name = "IsPrinted";
        }
        private void DesabilitarColunas()
        {
            dgvCompraDeGadoItens.Columns[4].Visible = false;
            dgvCompraDeGadoItens.Columns[5].Visible = false;
            dgvCompraDeGadoItens.Columns[6].Visible = false;
            dgvCompraDeGadoItens.Columns[7].Visible = false;
         }
        private void ObterPecuarista()
        {
            List<ModelPecuarista> oPecuarista = new List<ModelPecuarista>();

            oPecuarista = _obter.ObterPecuarista();

            if (oPecuarista.Count == 0)
            {
                MessageBox.Show("Não foi possível obter lista de pecuaristas");
            }
            else
            {
                cboPecuarista.DataSource = oPecuarista;
                cboPecuarista.DisplayMember = "Nome";
                cboPecuarista.ValueMember = "Id";
            }
        }
        private void ObterAnimal()
        {
            List<ModelAnimal> oAnimal = new List<ModelAnimal>();

            oAnimal = _obter.ObterAnimal();

            if (oAnimal.Count == 0)
            {
                MessageBox.Show("Não foi possível obter lista de animais");
            }
            else
            {
                cboAnimal.DataSource = oAnimal;
                cboAnimal.DisplayMember = "Descricao";
                cboAnimal.ValueMember = "Id";
            }
        }
        private void ObterCompraDeGadoIem(int idCompraDeGado)
        {
            List<Entidade.ModelCompraDeGadoItem> oModelCompraDeGadoList = new List<ModelCompraDeGadoItem>();

            oModelCompraDeGadoList = _obter.ObterCompraDeGadoIem(idCompraDeGado);

            if (oModelCompraDeGadoList.Count > 0)
            {
                Decimal ValorTotal = 0;

                foreach (var item in oModelCompraDeGadoList)
                {
                    string[] row = new string[] { item.Descricao, item.Quantidade.ToString(), item.Preco, 
                                                    item.ValorTotal, item.IdCompraDeGado.ToString(),
                                                    item.IdPecuarista.ToString(), item.IdAnimal.ToString(), item.DataEntrega, item.IsPrinted == "0" ? "Não" : "Sim"};

                    dgvCompraDeGadoItens.Rows.Add(row);

                    ValorTotal += Convert.ToDecimal(item.ValorTotal);
                }

                txtValorTotal.Text = string.Format("{0:c}", ValorTotal);
            }
            else
            {
                MessageBox.Show("Não foi possível obter lista de Itens Compra De Gado");
            }
        }
        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            string Animal = cboAnimal.Text.Substring(0, cboAnimal.Text.IndexOf("-") - 1);
            string Preco = cboAnimal.Text.Substring(cboAnimal.Text.IndexOf("-") + 2);
            string IdAnimal = cboAnimal.SelectedValue.ToString();

            try
            {
                Decimal ValorTotalItem = Convert.ToDecimal(Preco) * Convert.ToDecimal(txtQuantidade.Text);

                if (ValorTotalItem > 0)
                {
                    bool flag = true;

                    if (dgvCompraDeGadoItens.Rows.Count > 1)
                    {
                        for (Int32 i = 1; i < dgvCompraDeGadoItens.Rows.Count; i++)
                        {
                            if (dgvCompraDeGadoItens.Rows[i -1].Cells[0].Value.ToString().TrimEnd() == Animal.TrimEnd())
                            {
                                flag = false;

                                break;
                            }
                        }
                    }

                    if (flag)
                    {
                        Decimal QtdDecimal = Convert.ToDecimal(txtQuantidade.Text);

                        Decimal ValorTotal = 0;

                        int idCompraDeGadoNew = 0;

                        string Quantidade = txtQuantidade.Text;

                        string[] row = new string[] { Animal, 
                                                      Quantidade, 
                                                      Preco,
                                                      ValorTotalItem.ToString("n2"), 
                                                      idCompraDeGado.ToString(), 
                                                      cboPecuarista.SelectedValue.ToString(), 
                                                      cboAnimal.SelectedValue.ToString(), 
                                                      dtDataEntrega.Value.ToString("dd/MM/yyyy"),
                                                       "Não"};

                        dgvCompraDeGadoItens.Rows.Add(row);

                        string ValorTotalTB = txtValorTotal.Text.Replace("R$", "").Replace(".", "").Replace(".", "");

                        Decimal ValorTotalTBConvertido = Convert.ToDecimal(ValorTotalTB);

                        txtValorTotal.Text = string.Format("{0:c}", ValorTotalTBConvertido + ValorTotalItem);
                    }
                }
                else
                {
                    MessageBox.Show("Quantidade tem que ser maior que zero! ");
                }
            }
            catch (Exception)
            {
               MessageBox.Show("Quantidade tem que ser maior que zero! ");
            }
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar(idCompraDeGado);
        }
        private void Salvar(int idCompraDeGado)
        {
            List<Entidade.CompraGado> CompraDeGadoList = new List<CompraGado>();

            for (int i = 1; i < dgvCompraDeGadoItens.Rows.Count; i++)
            {
                Entidade.CompraGado oCompraDeGado = new Entidade.CompraGado();

                oCompraDeGado.IdCompraDeGado = idCompraDeGado;
                oCompraDeGado.DataEntrega = dtDataEntrega.Value.ToString("dd-MM-yyyy");
                oCompraDeGado.IdAnimal = Convert.ToInt32(dgvCompraDeGadoItens.Rows[i - 1].Cells[6].Value.ToString());
                oCompraDeGado.IdPecuarista = Convert.ToInt32(cboPecuarista.SelectedValue.ToString());
                oCompraDeGado.Quantidade = Convert.ToInt32(dgvCompraDeGadoItens.Rows[i - 1].Cells[1].Value.ToString());

                CompraDeGadoList.Add(oCompraDeGado);
            }

            bool result = _alterar.Salvar(idCompraDeGado, CompraDeGadoList);
            
            if (result)
            {
                MessageBox.Show("Compra de Gado efetuada com sucesso!");

                dgvCompraDeGadoItens.Rows.Clear();
                dgvCompraDeGadoItens.Refresh();

                if (idCompraDeGado > 0)
                {
                    ObterCompraDeGadoIem(idCompraDeGado);
                }
                else
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Não foi possível salvar.");
            }
        }
        private void dgvCompraDeGadoItens_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvCompraDeGadoItens.Rows.Count > 0 && dgvCompraDeGadoItens.SelectedRows.Count > 0)
            {
                int row = dgvCompraDeGadoItens.CurrentCell.RowIndex;

                txtQuantidade.Text = dgvCompraDeGadoItens.Rows[row].Cells[1].Value.ToString();
                cboAnimal.SelectedValue = Convert.ToInt32(dgvCompraDeGadoItens.Rows[row].Cells[6].Value.ToString());
                cboPecuarista.SelectedValue = Convert.ToInt32(dgvCompraDeGadoItens.Rows[row].Cells[5].Value.ToString());
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (idCompraDeGado == 0 || (dgvCompraDeGadoItens.Rows.Count > 2 && dgvCompraDeGadoItens.SelectedRows.Count > 0))
            {
                int row = dgvCompraDeGadoItens.CurrentCell.RowIndex;

                if (dgvCompraDeGadoItens.Rows[row].Cells[8].Value.ToString() == "Não")
                {
                    string ValorDgvItem = dgvCompraDeGadoItens.Rows[row].Cells[3].Value.ToString().Replace("R$", "").Replace(".", "");

                    Decimal ValorDgvItemConvertido = Convert.ToDecimal(ValorDgvItem);

                    string ValorTotalTB = txtValorTotal.Text.Replace("R$", "").Replace(".", "").Replace(".", "");

                    Decimal ValorTotalTBConvertido = Convert.ToDecimal(ValorTotalTB);

                    txtValorTotal.Text = string.Format("{0:c}", ValorTotalTBConvertido - ValorDgvItemConvertido);

                    dgvCompraDeGadoItens.Rows.RemoveAt(row);
                }
            }
            else if (dgvCompraDeGadoItens.Rows.Count == 2 && dgvCompraDeGadoItens.SelectedRows.Count > 0)
            {
                MessageBox.Show("Uma Compra de Gado precisa ter pelo menos um Item, favor alterar o já existente ou excluir a Compra de Gado na Tela Principal!");
            }
        }
        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (dgvCompraDeGadoItens.Rows.Count > 0 && dgvCompraDeGadoItens.SelectedRows.Count > 0)
            {
                int row = dgvCompraDeGadoItens.CurrentCell.RowIndex;

                if (dgvCompraDeGadoItens.Rows[row].Cells[8].Value.ToString() == "Não")
                {
                    bool flag = true;

                    string Animal = cboAnimal.Text.Substring(0, cboAnimal.Text.IndexOf("-") - 1);

                    if (dgvCompraDeGadoItens.Rows[row].Cells[0].Value.ToString() != Animal)
                    {
                        if (dgvCompraDeGadoItens.Rows.Count > 1)
                        {
                            for (Int32 i = 1; i < dgvCompraDeGadoItens.Rows.Count; i++)
                            {
                                if (dgvCompraDeGadoItens.Rows[i - 1].Cells[0].Value.ToString() == Animal)
                                {
                                    flag = false;

                                    break;
                                }
                            }
                        }
                    }

                    if (flag)
                    {

                        string ValorDgvItem = dgvCompraDeGadoItens.Rows[row].Cells[3].Value.ToString();

                        Decimal ValorDgvItemConvertido = Convert.ToDecimal(ValorDgvItem);

                        string ValorTotalTB = txtValorTotal.Text.Replace("R$", "").Replace(".", "").Replace(".", "");

                        Decimal ValorTotalTBConvertido = Convert.ToDecimal(ValorTotalTB);

                        Decimal ValorTotalItem = Convert.ToDecimal(txtQuantidade.Text) * Convert.ToDecimal(cboAnimal.Text.Substring(cboAnimal.Text.IndexOf("-") + 1));

                        txtValorTotal.Text = string.Format("{0:c}", (ValorTotalTBConvertido - ValorDgvItemConvertido) + ValorTotalItem);

                        dgvCompraDeGadoItens.Rows[row].Cells[0].Value = cboAnimal.Text.Substring(0, cboAnimal.Text.IndexOf("-"));
                        dgvCompraDeGadoItens.Rows[row].Cells[1].Value = txtQuantidade.Text;
                        dgvCompraDeGadoItens.Rows[row].Cells[2].Value = cboAnimal.Text.Substring(cboAnimal.Text.IndexOf("-") + 2);

                        dgvCompraDeGadoItens.Rows[row].Cells[3].Value = ValorTotalItem.ToString("n2");

                        dgvCompraDeGadoItens.Rows[row].Cells[4].Value = idCompraDeGado;
                        dgvCompraDeGadoItens.Rows[row].Cells[5].Value = cboPecuarista.SelectedValue.ToString();
                        dgvCompraDeGadoItens.Rows[row].Cells[6].Value = cboAnimal.SelectedValue.ToString();
                    }
                }
            }
        }
    }
}
