using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System;
using System.Security.Policy;
using System.Windows.Forms;
using System.Text;
using System.Reflection;
using Entidade.Interface;
using Entidade;
using Negocio;
using Ninject;

namespace CompraDeGado
{
    public partial class Form : System.Windows.Forms.Form
    {
        public static int RegistroIni, RegistroFim, TotalRegistros, TotalRegistrosGrid, TotalGrid;

        public List<ModelCompraDeGado> oModelCompraDeGadoList = new List<ModelCompraDeGado>();

        private iObter _obter;
        private iAlterar _alterar;

        public Form()
        {
            InitializeComponent();

            StandardKernel _kernel = new StandardKernel();

            _kernel.Load(Assembly.GetExecutingAssembly());

            _obter = _kernel.Get<iObter>();
            _alterar = _kernel.Get<iAlterar>();

            ObterPecuarista();
        }
        private void btnIncluir_Click(object sender, EventArgs e)
        {
            Manutencao frmManutencao = new Manutencao(0);

            frmManutencao.ShowDialog();

            ObterCompraDeGado();
        }
        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            ObterCompraDeGado();
        }
        private void ObterCompraDeGado()
        {

            string idCompraDeGado = string.IsNullOrEmpty(txtIDCompra.Text) ? "0" : txtIDCompra.Text;
            string DataIni = dtIni.Checked ? dtIni.Value.ToString("dd/MM/yyyy") : string.Empty;
            string DataFim = dtFim.Checked ? dtFim.Value.ToString("dd/MM/yyyy") : string.Empty;
            string IdComboPecuarista = cboPecuarista.SelectedIndex != -1 ? cboPecuarista.SelectedValue.ToString() : "0";

            if (idCompraDeGado != "0" ||  IdComboPecuarista != "0" || (dtIni.Checked && dtFim.Checked))
            {
                oModelCompraDeGadoList = _obter.ObterCompraDeGado(idCompraDeGado, IdComboPecuarista, DataIni, DataFim);

                TotalGrid = 0; TotalRegistrosGrid = 0; RegistroIni = 0; RegistroFim = 0;

                TotalRegistros = oModelCompraDeGadoList.Count;

                if (TotalRegistros == 0)
                {
                    MessageBox.Show("A pesquisa n�o retornou dados.");
                }
                else
                {
                    cboPecuarista.SelectedIndex = -1;
                    AlimentarGridAvancar(1, 10);
                }
            }
            else
            {
                MessageBox.Show("Preencha pelo menos um filtro de pesquisa");
            }
        }
        public void AlimentarGridAvancar(int registroIni, int registroFim)
        {
            List<ModelCompraDeGado> oModelCompraDeGadoListClone = new List<ModelCompraDeGado>();

            int countLin = 0;
            int countRec = 0;

            RegistroIni = TotalGrid == 0 ? registroIni : registroIni + 10;
            RegistroFim = TotalGrid == 0 ? registroFim : registroFim + 10;
 
            foreach (var item in oModelCompraDeGadoList)
            {
                countLin++;

                if (countLin >= RegistroIni && countLin <= RegistroFim)
                {
                    ModelCompraDeGado compraDeGado = new ModelCompraDeGado();

                    Decimal ValorTotal = Convert.ToDecimal(item.ValorTotal);

                    compraDeGado.DataEntrega = item.DataEntrega;
                    compraDeGado.Id = item.Id;
                    compraDeGado.ValorTotal = string.Format("{0:c}", ValorTotal);
                    compraDeGado.Pecuarista =  item.Pecuarista;

                    oModelCompraDeGadoListClone.Add(compraDeGado);

                    countRec++;
                    TotalRegistrosGrid++;
                }
            }

            if (countRec > 0) { TotalGrid++; }

            btnVoltar.Enabled = TotalGrid > 1 ? true : false;

            btnAvan�ar.Enabled = countRec < 10 || TotalRegistrosGrid == TotalRegistros ? false : true;

            dgvCompraDeGado.DataSource = oModelCompraDeGadoListClone;
        }
        public void AlimentarGridVoltar(int registroIni, int registroFim)
        {
            List<ModelCompraDeGado> oModelCompraDeGadoListClone = new List<ModelCompraDeGado>();

            int countLin = 0;

            RegistroIni = registroIni - 10;
            RegistroFim = registroFim - 10;

            foreach (var item in oModelCompraDeGadoList)
            {
                countLin++;

                if (countLin >= RegistroIni && countLin <= RegistroFim)
                {
                    ModelCompraDeGado compraDeGado = new ModelCompraDeGado();

                    Decimal ValorTotal = Convert.ToDecimal(item.ValorTotal);

                    compraDeGado.DataEntrega = item.DataEntrega;
                    compraDeGado.Id = item.Id;
                    compraDeGado.ValorTotal = string.Format("{0:c}", ValorTotal);
                    compraDeGado.Pecuarista = item.Pecuarista;

                    oModelCompraDeGadoListClone.Add(compraDeGado);
                }
            }

            TotalRegistrosGrid -= dgvCompraDeGado.Rows.Count;

            TotalGrid--;

            if (TotalGrid == 1) { btnAvan�ar.Enabled = true; btnVoltar.Enabled = false; }

            dgvCompraDeGado.DataSource = oModelCompraDeGadoListClone;
        }
        private void ObterPecuarista()
        {
            List<ModelPecuarista> oPecuarista = new List<ModelPecuarista>();

            oPecuarista = _obter.ObterPecuarista();

            if (oPecuarista.Count == 0)
            {
                MessageBox.Show("A pesquisa n�o retornou dados.");
            }
            else
            {
                cboPecuarista.DataSource = oPecuarista;
                cboPecuarista.DisplayMember = "Nome";
                cboPecuarista.ValueMember = "Id";
                cboPecuarista.SelectedIndex = -1;
            }
        }
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if(dgvCompraDeGado.Rows.Count > 0 && dgvCompraDeGado.SelectedRows.Count > 0)
            {
                int row = dgvCompraDeGado.CurrentCell.RowIndex;

                if (DialogResult.Yes == MessageBox.Show("Confirma a exclus�o da Compra de Gado Id: " + dgvCompraDeGado.Rows[row].Cells[0].Value.ToString() +  " ?", "Confirma", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    ExcluirCompraDeGado(Convert.ToInt32(dgvCompraDeGado.Rows[row].Cells[0].Value.ToString()));
                }
            }
        }
        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (dgvCompraDeGado.Rows.Count > 0 && dgvCompraDeGado.SelectedRows.Count > 0)
            {
                int row = dgvCompraDeGado.CurrentCell.RowIndex;

                bool result = Imprimir(Convert.ToInt32(dgvCompraDeGado.Rows[row].Cells[0].Value.ToString()));

                if (result)
                {
                    if (DialogResult.Yes == MessageBox.Show("Confirma a gera��o com sucesso do arquivo? ", "Confirma", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                    {
                        result = AtualizarIsPrinted(Convert.ToInt32(dgvCompraDeGado.Rows[row].Cells[0].Value.ToString()));

                        if (result)
                        {
                            MessageBox.Show("Atualiza��o do campo IsPrinted efetuada com sucesso");
                        }
                        else
                        {
                            MessageBox.Show("N�o foi poss�el efetuar a atualia��o da coluna IsPrinted");
                        }
                    }
                }
            }
        }
        private bool Imprimir(int idCompraDeGado)
        {
            if (DialogResult.Yes == MessageBox.Show("Confirma a impress�o da Compra de Gado Id: " + idCompraDeGado + " ?", "Confirma", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                SaveFileDialog save = new SaveFileDialog();

                save.FileName = "Marfrig.txt";

                save.Filter = "Text File | *.txt";

                if (save.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter writer = new StreamWriter(save.OpenFile());

                    List<ModelCompraDeGadoItem> oModelCompraDeGadoList = new();

                    oModelCompraDeGadoList = _obter.ObterCompraDeGadoIem(idCompraDeGado);

                    if (oModelCompraDeGadoList.Count > 0)
                    {
                        int countLine = 0;

                        int row = dgvCompraDeGado.CurrentCell.RowIndex;

                        var space = String.Concat(Enumerable.Repeat(" ", 10));
                        var traco = String.Concat(Enumerable.Repeat("-", 95));

                        foreach (var item in oModelCompraDeGadoList)
                        {
                            countLine++;

                            if (countLine == 1)
                            {
                                writer.WriteLine(space + space + space + "MARFRIG - RELAT�RIO DE COMPRA DE GADO");
                                writer.WriteLine("");
                                writer.WriteLine("");
                                writer.WriteLine("Id: " + item.IdCompraDeGado + space + space + "Data Entrega: " + item.DataEntrega + space + space + "Pecuarista: " + dgvCompraDeGado.Rows[row].Cells[1].Value.ToString());
                                writer.WriteLine(traco);
                                writer.WriteLine("Animal                    Quantidade                  Pre�o                   Valor Total");
                                writer.WriteLine(traco);
                            }

                            Decimal dPreco = Convert.ToDecimal(item.Preco);
                            Decimal dValorTotal = Convert.ToDecimal(item.ValorTotal);

                            string Descricao = item.Descricao + String.Concat(Enumerable.Repeat(" ", 29 - item.Descricao.Length));
                            string Quantidade = item.Quantidade + String.Concat(Enumerable.Repeat(" ", 22 - item.Quantidade.ToString().Length));
                            string Preco = string.Format("{0:c}", dPreco) + String.Concat(Enumerable.Repeat(" ", 22 - dPreco.ToString().Length));
                            string ValorTotal = string.Format("{0:c}", dValorTotal);

                            writer.WriteLine(Descricao + Quantidade + Preco + ValorTotal);
                        }

                        writer.Dispose();

                        writer.Close();
                    }
                }
            }

            return true;
        }
        public bool AtualizarIsPrinted(int idCompraDeGado)
        {
            return _alterar.AtualizarIsPrinted(idCompraDeGado);
        }
        private void ExcluirCompraDeGado(int IdCompraDeGado)
        {
            bool result = _alterar.ExcluirCompraDeGado(IdCompraDeGado);

            if (result)
            {
                MessageBox.Show("Compra de Gado exclu�da com sucesso");

                ObterCompraDeGado();
            }
            else
            {
                MessageBox.Show("N�o foi poss�vel excluir a Compra de Gado Id : " + IdCompraDeGado);
            }
        }
        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (dgvCompraDeGado.Rows.Count > 0 && dgvCompraDeGado.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvCompraDeGado.Rows[dgvCompraDeGado.SelectedCells[0].RowIndex];
                int IdCompraDeGado = Convert.ToInt32(row.Cells["Id"].Value);

                Manutencao frmManutencao = new Manutencao(IdCompraDeGado);

                frmManutencao.ShowDialog();
            }
        }
        private void btnAvan�ar_Click(object sender, EventArgs e)
        {
            AlimentarGridAvancar(RegistroIni, RegistroFim);
        }
        private void btnVoltar_Click(object sender, EventArgs e)
        {
            AlimentarGridVoltar(RegistroIni, RegistroFim);
        }
    }
}