﻿using Microsoft.Extensions.DependencyInjection;
using System;
using Entidade;
using Negocio;

namespace Utilitario
{
    public class Dependencia
    {
        public void InjecaoApi(IServiceCollection services)
        {
            //NEGOCIO
            services.AddScoped<Entidade.Interface.iObter, Negocio.Obter>();
        }
    }
}