﻿namespace Entidade
{
    public class ModelPecuaristaTeste
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}