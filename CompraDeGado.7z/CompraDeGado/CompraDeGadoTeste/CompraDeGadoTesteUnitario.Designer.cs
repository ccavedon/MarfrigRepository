﻿namespace CompraDeGadoTeste
{
    partial class CompraDeGadoTesteUnitario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvCompraDeGadoTeste = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompraDeGadoTeste)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCompraDeGadoTeste
            // 
            this.dgvCompraDeGadoTeste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCompraDeGadoTeste.Location = new System.Drawing.Point(35, 249);
            this.dgvCompraDeGadoTeste.Name = "dgvCompraDeGadoTeste";
            this.dgvCompraDeGadoTeste.Size = new System.Drawing.Size(735, 164);
            this.dgvCompraDeGadoTeste.TabIndex = 0;
            // 
            // CompraDeGadoTeste
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvCompraDeGadoTeste);
            this.Name = "CompraDeGadoTeste";
            this.Text = "CompraDeGadoTeste";
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompraDeGadoTeste)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvCompraDeGadoTeste;
    }
}

