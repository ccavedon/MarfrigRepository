using Moq;
using Entidade;
using Entidade.Interface;
using TesteUnitario.Mock;
using System.Diagnostics;

namespace TesteUnitario
{
    [TestClass]
    public class CompraDeGadoTeste
    {
        private TestContext testContextInstance;

        [TestMethod]
        public void TestMethod()
        {
            Mock<iObter> mockObter = new Mock<iObter>();

            List<ModelAnimal> oModelAnimalList = new List<ModelAnimal>();
            List<ModelPecuarista> oModelPecuaristaList = new List<ModelPecuarista>();
            List<ModelCompraDeGado> oModelCompraDeGadoList = new List<ModelCompraDeGado>();
            List<ModelCompraDeGadoItem> oModelCompraDeGadoItemList = new List<ModelCompraDeGadoItem>();

            ObterMock oObterlMock = new ObterMock();
            oModelAnimalList = oObterlMock.ObterAnimal();
            oModelPecuaristaList = oObterlMock.ObterPecuarista();
            oModelCompraDeGadoList = oObterlMock.ObterCompraDeGado();
            oModelCompraDeGadoItemList = oObterlMock.ObterCompraDeGadoItem();

            mockObter.Setup(m => m.ObterAnimal()).Returns(oModelAnimalList);
            mockObter.Setup(m => m.ObterPecuarista()).Returns(oModelPecuaristaList);
            mockObter.Setup(m => m.ObterCompraDeGado("1", "1", "1", "1")).Returns(oModelCompraDeGadoList);
            mockObter.Setup(m => m.ObterCompraDeGadoIem(1)).Returns(oModelCompraDeGadoItemList);

            var animalResult = mockObter.Object.ObterAnimal();
            var pecuaristraResult = mockObter.Object.ObterPecuarista();
            var compradegadolResult = mockObter.Object.ObterCompraDeGado("1", "1", "1", "1");
            var compradegadoitemResult = mockObter.Object.ObterCompraDeGadoIem(1);

            Mock<iAlterar> mockAlterar = new Mock<iAlterar>();

            List<CompraGado> mockCompraGadoList = new List<CompraGado>();

            AlterarMock oAlterarMock = new AlterarMock();
   
            mockAlterar.Setup(m => m.ExcluirCompraDeGado(1)).Returns(true);
            mockAlterar.Setup(m => m.Salvar(1, mockCompraGadoList)).Returns(true);
            mockAlterar.Setup(m => m.AtualizarIsPrinted(1)).Returns(true);

            var resultExcluir = mockAlterar.Object.ExcluirCompraDeGado(1);
            var resulSalvar = mockAlterar.Object.Salvar(1, mockCompraGadoList);
            var resultarAtualizarIsPrinted = mockAlterar.Object.AtualizarIsPrinted(1);

            Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));
            //Trace.Listeners.Add(new ConsoleTraceListener());

            Trace.WriteLine("Compra de Gado");

            foreach (var item in compradegadolResult)
            {
                Trace.WriteLine("Id: " + item.Id + " Pecuarista: " + item.Pecuarista + " Data Entrega: " +  item.DataEntrega + " Valor Total: " + item.ValorTotal);
            }

            Trace.WriteLine("Pecuarista");

            foreach (var item in pecuaristraResult)
            {
                Trace.WriteLine("Id: " + item.Id + " Pecuarista: " + item.Nome);
            }

            Trace.WriteLine("Animal");

            foreach (var item in animalResult)
            {
                Trace.WriteLine("Id: " + item.Id + " Descri��o: " + item.Descricao);
            }

            Trace.WriteLine("Itens Compra de Gado");

            foreach (var item in compradegadoitemResult)
            {
                Trace.WriteLine("Animal: " + item.Descricao + " Quantidade: " + item.Quantidade + " Pre�o: " + item.Preco + " Valor Total: " + item.ValorTotal);
            }

            Trace.WriteLine("Resultado Excluir: " + resultExcluir);
            Trace.WriteLine("Resultado Salvar: " + resulSalvar);
            Trace.WriteLine("Resultado Atualizar IsPrinted: " + resultarAtualizarIsPrinted);
        }
    }
}