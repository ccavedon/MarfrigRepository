﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidade;

namespace TesteUnitario.Mock
{
    public class AlterarMock
    {
        public bool ExcluirCompraDeGado(int idCompraDeGado)
        {
            return true;
        }
        public bool Salvar(int idCompraDeGado, List<CompraGado> CompraDeGadoList)
        {
            return true;
        }
        public bool AtualizarIsPrinted(int idCompraDeGado)
        {
            return true;
        }



    }
}
