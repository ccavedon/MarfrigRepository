﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidade;

namespace TesteUnitario
{
    public class ObterMock
    {
        public List<ModelAnimal> ObterAnimal()
        {
            List<ModelAnimal> oModelAnimalList = new List<ModelAnimal>();

            string[] animalList = { "Nelore" , "Holandes" , "Mestico", "Angus", "Simental", "Azul Belga" };
            decimal Preco = 1000;

            for (int i = 1; i <= 6; i++)
            {
                ModelAnimal oModelAnimal = new ModelAnimal();

                Preco += 100;

                oModelAnimal.Id = i;
                oModelAnimal.Descricao = animalList[i - 1] + "-" + Preco.ToString("n2");
                oModelAnimal.Preco = Preco;

                oModelAnimalList.Add(oModelAnimal);
            }

            return oModelAnimalList;
        }

        public List<ModelPecuarista> ObterPecuarista()
        {
            List<ModelPecuarista> oModelPecuaristaList = new List<ModelPecuarista>();

            for (int i = 1; i <= 6; i++)
            {
                ModelPecuarista oModelPecuarista = new ModelPecuarista();

                oModelPecuarista.Id = i;
                oModelPecuarista.Nome = "Pecuarista - " + i.ToString();

                oModelPecuaristaList.Add(oModelPecuarista);
            }

            return oModelPecuaristaList;
        }

        public List<ModelCompraDeGado> ObterCompraDeGado()
        {
            List<ModelCompraDeGado> oModelCompraDeGadoList = new List<ModelCompraDeGado>();

            decimal Preco = 100000;
            Random rnd = new Random();

            for (int i = 1; i <= 10; i++)
            {
                ModelCompraDeGado oModelCompraDeGado = new ModelCompraDeGado();

                oModelCompraDeGado.Id = i;
                oModelCompraDeGado.DataEntrega = "20/08/2022";
                oModelCompraDeGado.Pecuarista = "Pecuarista " + i.ToString();
                oModelCompraDeGado.ValorTotal = (Preco * rnd.Next(8,10)).ToString("n2");

                oModelCompraDeGadoList.Add(oModelCompraDeGado);
            }

            return oModelCompraDeGadoList;
        }

        public  List<ModelCompraDeGadoItem> ObterCompraDeGadoItem()
        {
            List<ModelCompraDeGadoItem> oModelCompraDeGadoItemList = new List<ModelCompraDeGadoItem>();

            string[] animalList = { "Nelore", "Holandes", "Mestico", "Angus", "Simental", "Azul Belga" };

            decimal Preco = 1000;

            for (int i = 1; i <= 6; i++)
            {
                Preco += 100;

                ModelCompraDeGadoItem oModelCompraDeGadoItem = new ModelCompraDeGadoItem();

                oModelCompraDeGadoItem.Descricao = animalList[i - 1];
                oModelCompraDeGadoItem.Quantidade = i * 100;
                oModelCompraDeGadoItem.Preco = Preco.ToString("n2");
                oModelCompraDeGadoItem.ValorTotal = (Preco * (i * 100)).ToString("n2");
                oModelCompraDeGadoItem.IsPrinted = "0";

                oModelCompraDeGadoItemList.Add(oModelCompraDeGadoItem);
            }

            return oModelCompraDeGadoItemList;
        }

    }
}
