﻿namespace Entidade
{
    public class CompraGado
    {
        public int IdCompraDeGado { get; set; }
        public int IdCompraDeGadoItem { get; set; }
        public int IdPecuarista { get; set; }
        public int IdAnimal { get; set; }
        public int Quantidade { get; set; }
        public string DataEntrega { get; set; }
    }
}
