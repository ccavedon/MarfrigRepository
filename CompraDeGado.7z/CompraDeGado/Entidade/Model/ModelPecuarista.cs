﻿namespace Entidade
{
    public class ModelPecuarista
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}