﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidade.Interface
{
    public interface iAlterar
    {
        public bool ExcluirCompraDeGado(int idCompraDeGado);
        public bool Salvar(int idCompraDeGado, List<CompraGado> CompraDeGadoList);
        public bool AtualizarIsPrinted(int idCompraDeGado);
    }
}