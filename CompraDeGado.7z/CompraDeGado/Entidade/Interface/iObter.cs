﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidade.Interface
{
    public interface iObter
    {
        public List<ModelCompraDeGado> ObterCompraDeGado(string idCompraDeGado, string idPecuarista, string dataIni, string dataFim);
        public List<ModelCompraDeGadoItem> ObterCompraDeGadoIem(int idCompraDeGado);
        public List<ModelPecuarista> ObterPecuarista();
        public List<ModelAnimal> ObterAnimal();
    }
}