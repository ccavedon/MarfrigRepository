﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidade;
using Entidade.Interface;

namespace Negocio
{
    public class Alterar : iAlterar
    {
        public string strURL = "https://localhost:44364/CompraDeGado";
        public bool ExcluirCompraDeGado(int idCompraDeGado)
        {
            string sApi = strURL + "/ExcluirCompraDeGado?IdCompraDeGado=" + idCompraDeGado;              

            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi) };

            var response = client.DeleteAsync(sApi).Result;

            var ExcluirJsonString = response.Content.ReadAsStringAsync();

            bool result = JsonConvert.DeserializeObject<bool>(ExcluirJsonString.Result);

            return true;
        }
        public bool Salvar(int idCompraDeGado, List<CompraGado> CompraDeGadoList)
        {
            string sAcao = idCompraDeGado.ToString() == "0" ? "/Adicionar" : "/Salvar";

            string sApi = strURL + sAcao;

            var json = JsonConvert.SerializeObject(CompraDeGadoList);
            var data = new StringContent(json, Encoding.UTF8, "application/json");

            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi) };

            var response = client.PostAsync(sApi, data).Result;

            var SalvarJsonString = response.Content.ReadAsStringAsync();

            bool result = JsonConvert.DeserializeObject<bool>(SalvarJsonString.Result);

            return result;
        }
        public bool AtualizarIsPrinted(int idCompraDeGado)
        {
            string sApi = strURL + "/AtualizarIsPrinted";

            var json = JsonConvert.SerializeObject(idCompraDeGado);
            var data = new StringContent(json, Encoding.UTF8, "application/json");

            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi) };

            var response = client.PostAsync(sApi, data).Result;

            var ExcluirJsonString = response.Content.ReadAsStringAsync();

            bool result = JsonConvert.DeserializeObject<bool>(ExcluirJsonString.Result);

            return true;
        }
    }
}
