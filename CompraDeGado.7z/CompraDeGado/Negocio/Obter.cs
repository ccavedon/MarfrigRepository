﻿using Entidade;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using Entidade.Interface;
using System.Collections.Generic;

namespace Negocio
{
    public class Obter : iObter
    {
        public string strURL = "https://localhost:44364/CompraDeGado";

        public List<ModelCompraDeGado> ObterCompraDeGado(string idCompraDeGado, string idPecuarista, string dataIni, string dataFim)
        {
            List<ModelCompraDeGado> oModelCompraDeGadoList = new List<ModelCompraDeGado>();

            string sApi = strURL + "/ObterCompraDeGado?idCompraDeGado=" + idCompraDeGado + "&idPecuarista=" + idPecuarista + "&dataIni= " + dataIni + "&DataFim=" + dataFim;
            
            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi)};

            var response = client.GetAsync(sApi).Result;

            var CompraDeGadoJsonString = response.Content.ReadAsStringAsync();

            oModelCompraDeGadoList = JsonConvert.DeserializeObject<Entidade.ModelCompraDeGado[]>(CompraDeGadoJsonString.Result).ToList();

            return oModelCompraDeGadoList;

        }
        public List<ModelCompraDeGadoItem> ObterCompraDeGadoIem(int idCompraDeGado)
        {
            List<ModelCompraDeGadoItem> oModelCompraDeGadoList = new List<ModelCompraDeGadoItem>();

            string sApi = strURL + "/ObterCompraDeGadoItem?idCompraDeGado=" + idCompraDeGado;

            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi) };

            var response = client.GetAsync(sApi).Result;

            var CompraDeGadoItemJsonString = response.Content.ReadAsStringAsync();

            oModelCompraDeGadoList = JsonConvert.DeserializeObject<Entidade.ModelCompraDeGadoItem[]>(CompraDeGadoItemJsonString.Result).ToList();

            return oModelCompraDeGadoList;
        }
        public List<ModelPecuarista> ObterPecuarista()
        {
            List<ModelPecuarista> oPecuarista = new List<ModelPecuarista>();    

            string sApi = strURL + "/ObterPecuarista";

            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi) };

            var response = client.GetAsync(sApi).Result;

            var PecuaristaJsonString = response.Content.ReadAsStringAsync();

            oPecuarista = JsonConvert.DeserializeObject<ModelPecuarista[]>(PecuaristaJsonString.Result).ToList();

            return oPecuarista;
        }

        public List<ModelAnimal> ObterAnimal()
        {
            List<ModelAnimal> oAnimal = new List<ModelAnimal>();

            string sApi = strURL + "/ObterAnimal";

            HttpClient client = new HttpClient() { BaseAddress = new Uri(sApi) };

            var response = client.GetAsync(sApi).Result;

            var AnimalJsonString = response.Content.ReadAsStringAsync();

            oAnimal = JsonConvert.DeserializeObject<ModelAnimal[]>(AnimalJsonString.Result).ToList();

            return oAnimal;
        }
    }
}